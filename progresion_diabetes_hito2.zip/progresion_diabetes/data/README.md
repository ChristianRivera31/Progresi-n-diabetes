# Datos

## Origen

Dataset de diabetes incluido en scikit-learn (`sklearn.datasets.load_diabetes`).
Fuente original: B. Efron, T. Hastie, I. Johnstone y R. Tibshirani, "Least Angle Regression",
*Annals of Statistics*, 32(2), 2004.

## Licencia y privacidad

- Se distribuye junto con scikit-learn (licencia BSD de 3 cláusulas) y es de uso público para investigación.
- No contiene datos personales identificables: son 442 registros anónimos con variables numéricas.

## Contenido

- 442 pacientes, 10 variables: `age`, `sex`, `bmi`, `bp`, `s1` a `s6` (mediciones de suero).
- Objetivo `target`: medida cuantitativa de la progresión de la enfermedad un año después.
- Sin valores faltantes. Se usan los valores originales (`scaled=False`); el escalado se hace dentro del pipeline del modelo para evitar fuga de datos.

## Archivos (los crea `python src/prepare_data.py`)

| Archivo | Filas | Uso |
|---|---|---|
| `diabetes_raw.csv` | 442 | Datos completos |
| `train.csv` | 353 (80 %) | Entrenamiento y validación cruzada |
| `test.csv` | 89 (20 %) | Reservado para la evaluación final (Hito 3) |

Partición aleatoria con semilla `42`.

## Limitaciones conocidas

- Es un dataset clásico y pequeño; no es del contexto colombiano.
- La variable `sex` viene codificada como 1 y 2 sin que la documentación de scikit-learn indique cuál es cuál; se reporta como `sexo=1` y `sexo=2`.
