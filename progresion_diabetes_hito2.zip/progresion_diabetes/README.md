# Predicción de la progresión de diabetes (Ruta C: aprendizaje automático)

Proyecto final de IA. **Estado: Hito 2 (Avance)**: datos listos, línea base ejecutada y primer resultado guardado.

## Problema

Estimar la progresión de la diabetes un año después a partir de 10 variables clínicas (regresión supervisada).
Las métricas y umbrales de éxito están declarados en [`docs/propuesta_metricas.md`](docs/propuesta_metricas.md).

## Instalación y ejecución (4 comandos)

```bash
python -m venv .venv && source .venv/bin/activate   # en Windows: .venv\Scripts\activate
pip install -r requirements.txt
python src/prepare_data.py     # exporta los datos y crea la partición train/test
python src/baseline.py         # ejecuta la línea base y guarda resultados en experiments/
```

Semilla global: `42` (en `src/config.py`). Los resultados deben coincidir con `experiments/baseline_results.json`.

## Estructura

| Ruta | Contenido |
|---|---|
| `data/` | Datos y su documentación (`data/README.md`) |
| `src/` | Código: `config.py`, `prepare_data.py`, `baseline.py` |
| `experiments/` | Resultados de la línea base (CSV, JSON y figura) |
| `docs/` | `propuesta_metricas.md`, `bitacora_ia.md`, PDF del Hito 2 |
| `notebooks/` | Exploración (se agrega en el Hito 3) |

## Resultado actual (validación cruzada 5x5 sobre entrenamiento)

| Modelo | RMSE | MAE | R² |
|---|---|---|---|
| Media (dummy) | 78.17 ± 0.09 | 66.66 ± 0.12 | -0.006 ± 0.002 |
| Regresión lineal | 55.70 ± 0.18 | 45.28 ± 0.18 | 0.489 ± 0.003 |

El conjunto de prueba no se ha usado.
