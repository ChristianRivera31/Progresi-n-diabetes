# Evaluación definida antes de experimentar

> Este archivo se escribió **antes** de ejecutar cualquier línea base (ver historial de commits).
> Si se cambia algo después, hay que justificarlo por escrito al final de este archivo.

## Tarea de aprendizaje (Ruta C: aprendizaje automático supervisado)

- **Entrada:** 10 variables clínicas de un paciente (edad, sexo, IMC, presión arterial media y 6 mediciones de suero).
- **Salida:** un número que mide la progresión de la diabetes un año después de la línea de base (`target`).
- **Tipo de tarea:** regresión.

## Métricas

| Métrica | Rol | Por qué |
|---|---|---|
| **RMSE** | Principal | Penaliza más los errores grandes, que son los más peligrosos clínicamente. Está en las mismas unidades que el objetivo. |
| MAE | Secundaria | Error típico, más fácil de interpretar. |
| R² | Secundaria | Fracción de la variabilidad explicada, comparable entre modelos. |
| RMSE por subgrupo (sexo, rango de edad) | Equidad | Detecta si el modelo funciona peor para algún grupo. |

## Protocolo

- Partición: 80 % entrenamiento / 20 % prueba, semilla `42`.
- El **conjunto de prueba no se toca** hasta la entrega final (Hito 3).
- Todo lo demás se mide con **validación cruzada 5-fold repetida 5 veces** sobre el conjunto de entrenamiento (semillas fijas).
- Se reporta media ± desviación estándar entre repeticiones.

## Umbrales de éxito

1. **Valor mínimo:** el mejor modelo reduce el RMSE al menos **25 %** frente a la línea base más simple (predecir siempre la media).
2. **Valor del modelo avanzado:** el modelo más complejo (Hito 3) mejora el RMSE al menos **3 %** frente a la regresión lineal. Si no lo logra, la conclusión honesta es que la regresión lineal es suficiente para estos datos.
3. **Equidad:** el cociente entre el RMSE del peor subgrupo y el del mejor no supera **1.25**.

## Comparación mínima de la ruta C

Línea base (media y regresión lineal) **vs.** al menos 2 modelos con ajuste de hiperparámetros (Hito 3).

## Cambios posteriores justificados

_(ninguno por ahora)_
