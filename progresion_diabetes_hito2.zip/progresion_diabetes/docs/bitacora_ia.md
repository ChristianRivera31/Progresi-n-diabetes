# Bitácora humano-IA

| Fecha | Integrante | Herramienta | Para qué se usó | Qué se aceptó, modificó o descartó | Cómo se verificó |
|---|---|---|---|---|---|
| 2026-11-16 | [completar] | Claude (Sonnet 5.5) | Proponer tema, ruta y métricas: Ruta C con el dataset de diabetes de scikit-learn, métricas RMSE/MAE/R² y tres umbrales de éxito | Se aceptó la Ruta C y el dataset. Los umbrales (25 % sobre la media, 3 % del modelo avanzado sobre la regresión lineal, cociente de equidad ≤ 1.25) los propuso la IA: [completar si el equipo los modificó] | Se contrastó con los requisitos de la Ruta C del documento del proyecto (línea base, 2 modelos + ajuste, métricas típicas). Las métricas se escribieron en `docs/propuesta_metricas.md` antes de ejecutar la línea base |
| 2026-11-16 | [completar] | Claude (Sonnet 5.5) | Generar el código de `src/` (partición de datos, línea base con validación cruzada repetida, métricas por subgrupo) | Se aceptó el código. Un primer intento de ejecución con `python -I` falló porque no encontraba `config.py`; se corrigió usando `python src/...` sin ese flag | Se ejecutó de principio a fin: 442 filas, 353 de entrenamiento, 89 de prueba, sin faltantes; resultados reproducibles (desviación entre repeticiones < 0.6 de RMSE) |
| 2026-11-16 | [completar] | Claude (Sonnet 5.5) | Redactar README, documentación de datos y la página de avance del Hito 2 | Se aceptaron los textos; el equipo debe completar nombres y revisar cada afirmación | Se ejecutaron los comandos del README en un entorno limpio y se comparó el resultado con `experiments/baseline_results.json` |

## Recordatorio para la sustentación

Cada integrante debe poder explicar cualquier parte del código y de las métricas. Antes del Hito 3, completar las celdas marcadas con `[completar]` y agregar la reflexión sobre un caso en que la IA propuso algo incorrecto.
