"""Línea base: predictor de la media y regresión lineal.

Evalúa con validación cruzada 5-fold repetida 5 veces sobre el conjunto de
ENTRENAMIENTO (el de prueba no se toca). Guarda resultados en experiments/.
"""
import json

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from sklearn.base import clone
from sklearn.dummy import DummyRegressor
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from sklearn.model_selection import KFold
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler

import config as cfg

MODELS = {
    "media (dummy)": DummyRegressor(strategy="mean"),
    "regresion_lineal": make_pipeline(StandardScaler(), LinearRegression()),
}


def rmse(y, p) -> float:
    return float(np.sqrt(mean_squared_error(y, p)))


def age_group(age: pd.Series) -> pd.Series:
    return pd.cut(age, bins=[0, 39, 59, 200], labels=["<40", "40-59", ">=60"])


def oof_predictions(model, X: pd.DataFrame, y: pd.Series, seed: int) -> np.ndarray:
    """Predicciones fuera de muestra: cada fila se predice con un modelo que no la vio."""
    pred = np.zeros(len(y))
    kf = KFold(n_splits=cfg.CV_FOLDS, shuffle=True, random_state=seed)
    for tr, va in kf.split(X):
        m = clone(model).fit(X.iloc[tr], y.iloc[tr])
        pred[va] = m.predict(X.iloc[va])
    return pred


def main() -> None:
    cfg.EXP_DIR.mkdir(exist_ok=True)
    cfg.FIG_DIR.mkdir(parents=True, exist_ok=True)

    train = pd.read_csv(cfg.TRAIN_CSV)
    X, y = train[cfg.FEATURES], train[cfg.TARGET]
    sex_label = train["sex"].map({1: "sexo=1", 2: "sexo=2"})
    groups = {"sexo": sex_label, "edad": age_group(train["age"]).astype(str)}

    rows, sub_rows = [], []
    last_oof = {}
    for name, model in MODELS.items():
        for rep in range(cfg.CV_REPEATS):
            seed = cfg.SEED + rep
            pred = oof_predictions(model, X, y, seed)
            rows.append({
                "modelo": name, "repeticion": rep, "seed": seed,
                "rmse": rmse(y, pred),
                "mae": float(mean_absolute_error(y, pred)),
                "r2": float(r2_score(y, pred)),
            })
            for gname, g in groups.items():
                for level in sorted(g.unique()):
                    mask = (g == level).to_numpy()
                    sub_rows.append({
                        "modelo": name, "repeticion": rep, "variable": gname,
                        "grupo": level, "n": int(mask.sum()),
                        "rmse": rmse(y[mask], pred[mask]),
                    })
            last_oof[name] = pred

    folds = pd.DataFrame(rows)
    folds.to_csv(cfg.EXP_DIR / "baseline_cv_folds.csv", index=False)

    summary = (folds.groupby("modelo")[["rmse", "mae", "r2"]]
               .agg(["mean", "std"]).round(3))
    summary.columns = [f"{m}_{s}" for m, s in summary.columns]
    summary.to_csv(cfg.EXP_DIR / "baseline_summary.csv")

    sub = pd.DataFrame(sub_rows)
    sub_summary = (sub.groupby(["modelo", "variable", "grupo"])
                   .agg(n=("n", "first"), rmse_mean=("rmse", "mean"), rmse_std=("rmse", "std"))
                   .round(3).reset_index())
    sub_summary.to_csv(cfg.EXP_DIR / "baseline_subgroups.csv", index=False)

    # Peores 10 casos de la regresión lineal (inicio del análisis de errores)
    pred_lin = last_oof["regresion_lineal"]
    worst = train.copy()
    worst["prediccion"] = pred_lin.round(1)
    worst["error_abs"] = (worst[cfg.TARGET] - worst["prediccion"]).abs().round(1)
    worst["error_firmado"] = (worst["prediccion"] - worst[cfg.TARGET]).round(1)
    worst = worst.sort_values("error_abs", ascending=False).head(10)
    worst["tipo_error"] = np.where(worst["error_firmado"] < 0, "subestima progresión", "sobreestima progresión")
    worst["hipotesis_causa"] = "POR COMPLETAR (Hito 3)"
    worst.to_csv(cfg.EXP_DIR / "baseline_worst_cases.csv", index=False)

    # Cociente de equidad (peor/mejor RMSE por subgrupo) para la regresión lineal
    lin = sub_summary[sub_summary["modelo"] == "regresion_lineal"]
    ratios = {v: round(float(d["rmse_mean"].max() / d["rmse_mean"].min()), 3)
              for v, d in lin.groupby("variable")}

    mean_rmse = float(summary.loc["media (dummy)", "rmse_mean"])
    lin_rmse = float(summary.loc["regresion_lineal", "rmse_mean"])
    result = {
        "semilla_base": cfg.SEED,
        "cv": f"{cfg.CV_FOLDS}-fold x {cfg.CV_REPEATS} repeticiones, solo conjunto de entrenamiento",
        "n_entrenamiento": int(len(train)),
        "rmse_media": round(mean_rmse, 3),
        "rmse_regresion_lineal": round(lin_rmse, 3),
        "mejora_relativa_vs_media": round(1 - lin_rmse / mean_rmse, 3),
        "umbral_1_mejora_minima_25pct": bool(1 - lin_rmse / mean_rmse >= 0.25),
        "cociente_equidad_regresion_lineal": ratios,
        "umbral_3_equidad_max_1.25": {k: bool(v <= 1.25) for k, v in ratios.items()},
    }
    (cfg.EXP_DIR / "baseline_results.json").write_text(
        json.dumps(result, indent=2, ensure_ascii=False), encoding="utf-8")

    # Figura: real vs. predicho (regresión lineal, última repetición)
    fig, ax = plt.subplots(figsize=(4.2, 3.6), dpi=150)
    ax.scatter(y, pred_lin, s=10, alpha=0.6)
    lim = [min(y.min(), pred_lin.min()), max(y.max(), pred_lin.max())]
    ax.plot(lim, lim, "k--", lw=1)
    ax.set_xlabel("Progresión real")
    ax.set_ylabel("Progresión predicha")
    ax.set_title("Regresión lineal (validación cruzada)")
    fig.tight_layout()
    fig.savefig(cfg.FIG_DIR / "baseline_real_vs_predicho.png")

    print(summary.to_string())
    print()
    print(json.dumps(result, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
