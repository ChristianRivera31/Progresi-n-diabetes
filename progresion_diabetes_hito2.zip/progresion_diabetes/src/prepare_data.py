"""Exporta el dataset de diabetes de scikit-learn y crea la partición train/test.

El dataset viene incluido en scikit-learn, por lo que no necesita descarga.
Fuente original: Efron, Hastie, Johnstone y Tibshirani (2004), "Least Angle
Regression", Annals of Statistics 32(2).
"""
import pandas as pd
from sklearn.datasets import load_diabetes
from sklearn.model_selection import train_test_split

import config as cfg


def main() -> None:
    cfg.DATA_DIR.mkdir(exist_ok=True)

    # scaled=False deja los valores originales (sin estandarizar)
    bunch = load_diabetes(as_frame=True, scaled=False)
    df = bunch.frame.copy()
    df.to_csv(cfg.RAW_CSV, index=False)

    train, test = train_test_split(df, test_size=cfg.TEST_SIZE, random_state=cfg.SEED)
    train.to_csv(cfg.TRAIN_CSV, index=False)
    test.to_csv(cfg.TEST_CSV, index=False)

    print(f"Filas totales: {len(df)} | train: {len(train)} | test: {len(test)}")
    print(f"Valores faltantes: {int(df.isna().sum().sum())}")
    print("Datos guardados en data/ (el conjunto de prueba no se usa hasta el Hito 3)")


if __name__ == "__main__":
    main()
