"""Configuración central del proyecto (semillas, rutas y parámetros)."""
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
DATA_DIR = ROOT / "data"
EXP_DIR = ROOT / "experiments"
FIG_DIR = EXP_DIR / "figures"

SEED = 42            # semilla global
TEST_SIZE = 0.20     # 80 % entrenamiento / 20 % prueba
CV_FOLDS = 5         # validación cruzada
CV_REPEATS = 5       # repeticiones de la validación cruzada

TARGET = "target"
FEATURES = ["age", "sex", "bmi", "bp", "s1", "s2", "s3", "s4", "s5", "s6"]

RAW_CSV = DATA_DIR / "diabetes_raw.csv"
TRAIN_CSV = DATA_DIR / "train.csv"
TEST_CSV = DATA_DIR / "test.csv"
